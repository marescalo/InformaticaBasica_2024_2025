#include <iostream>
#include <vector>
#include <ctime>

double ReduceSum(std::vector<double> vector);
std::vector<double> GenerateVector(const int longitud, const double minimo, const double maximo);