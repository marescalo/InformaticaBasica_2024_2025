#include <iostream>
#include <vector>
#include <ctime>

double CalcularVector(std::vector<double>& vector_A, double& maximo, double& minimo, double& promedio);
std::vector<double> GenerateVector(const int longitud, const double minimo, const double maximo);