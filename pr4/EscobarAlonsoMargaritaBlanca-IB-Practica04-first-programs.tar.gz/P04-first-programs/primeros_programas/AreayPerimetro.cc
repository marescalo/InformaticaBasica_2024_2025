/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief Este programa no tan educado te pide tu nombre y tu edad para saludarte
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>

int main(){
    int lado {};

    std::cin >> lado;

    std::cout << "Area " << (lado * lado) << std::endl;
    std::cout << "Perimetro " << (4 * lado) << std::endl;

    return 0;
}