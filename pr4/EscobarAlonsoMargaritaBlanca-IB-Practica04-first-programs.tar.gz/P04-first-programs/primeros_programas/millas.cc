/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief 
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>
using namespace std;

int main() {
   float ml, km;
   cout << "Milles? ";
   cin >> ml;
   km = ml * 1.609;  // 1 //
   cout << "Són " << km << " kilòmetres" << endl;
}