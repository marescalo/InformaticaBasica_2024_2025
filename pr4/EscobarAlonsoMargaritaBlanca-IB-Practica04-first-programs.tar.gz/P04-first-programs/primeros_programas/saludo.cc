/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief Este programa muy educado saluda a el programador
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>
using namespace std;

int main() {
   string nombre; // 1 //

   cout << "Tu nombre? ";
   cin >> nombre; // 2 //

   cout << "Muy buenas, " << nombre
        << ", eres un gran programador." << endl; // 3 //
    
    return 0;
}