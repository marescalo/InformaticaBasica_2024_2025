/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief 
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>

int main(){
    long num1{};
    long num2{};

    std::cin >> num1 >> num2;
    std::cout << num1*num2 << std::endl;

    return 0;
}
