/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief este programa imprime una cruz
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>

int main(){

    std::cout << "*" << "   " << "*" << std::endl;
    std::cout << " " << "*" << " " << "*" << std::endl;
    std::cout << "  " << "*" << std::endl;
    std::cout << " " << "*" << " " << "*" << std::endl;
    std::cout << "*" << "   " << "*" << std::endl;

    return 0;
}