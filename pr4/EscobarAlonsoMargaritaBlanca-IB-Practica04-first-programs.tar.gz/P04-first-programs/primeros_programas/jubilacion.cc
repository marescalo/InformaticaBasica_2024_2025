/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief calcula cuanto te queda para la jubilacion
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>

int main(){
    int age{};
    int jubilacion {65};

    std::cout << "Introduce tu edad" << std::endl;
    std::cin >> age;

    std::cout << "Te quedan " << (jubilacion - age) << " años para jubilarte" << std::endl;
    return 0;
}