/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 4 Jun 2020
 * @brief Este programa no tan educado te pide tu nombre y tu edad para saludarte
 *
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 */

#include <iostream>

int main(){
    std::string name;
    int edad {0};

    std::cout << "Introduce tu nombre y tu edad" << std::endl;
    std::cin >> name;
    std::cin >> edad;

    std::cout << "Hola, eres " << name << " y tienes " << edad << " años" << std::endl;
    return 0;
}